from django.contrib.auth.backends import BaseBackend
from myapp.models import User
from django.db import models

class EmailBackend(BaseBackend):


    def authenticate(self,request,username=None,password=None,**kwargs):

        try:
            user_instance=User.objects.get(email=username)

            if user_instance.check_password(password):

                return user_instance
            else:
                    
                    return None
            
        except:
             
             return None
        
    def get_user(self,user_id):
            
            try:
                
                user_instance=User.objects.get(id=user_id)
                
                return user_instance
            
            except:
                
                return None

class PhoneBackend(BaseBackend):
     
    def authenticate(self, request, username=None,Password=None,**kwargs):
          
        try:
             
            user_instance=User.objects.get(phone=username)

            if user_instance.check_password(Password):
                 
                 return user_instance
            
            else:
                 
                 return None
            
        except:
             
             return None
        

    def get_user(self,user_id):
            
            try:
                
                user_instance=User.objects.get(id=user_id)
                
                return user_instance
            
            except:
                
                return None


class Profile(models.Model):
     
    owner=models.OneToOneField(User,on_delete=models.CASCADE,related_name="userprofile")

    address=models.TextField(null=True)

    bio=models.CharField(max_length=200,null=True)

    picture=models.ImageField(upload_to="profilepictures",null=True,blank=True,default="profilepictures/default.pn")



def create_profile(sender,instance,created,**kwargs):
     
    if created:
          
        Profile.objects.create(owner=instance)
     
   